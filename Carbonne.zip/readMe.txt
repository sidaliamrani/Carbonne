Pour exécuter le programme sous eclipse, il faut suivre les étapes suivantes :
. Lancer Eclipse
. Ouvrir le menu File/import
. Choisir General/Projects from folder
. Selectionner le repertoire "Carbonne"
. Importer puis compiler et lancer

Nb : c'est la classe Main qui contient la fonction main du projet et qui permet l'utilisation de la console.

Avant de lancer le programme vous avec 2 possibilitées :
1/ la premiere ne permet aucune intercation entre la machine et l'utlisateur, les informations lui parviennent directent du fichier test
2/ La seconde crée une intéraction entre la machine et l'utilisateur. Voici le scenario :
  Nombre de moyens de transport:
  Nombre de logement: 
  % de repas de vegetau :
  % de repas de boeuf :
  Le montant est de :
  La Superficie est de : 
  Choisir un chiffre entre 1 et 7 (ou A vaut 1, B vaut 2 ect...):
  Avez vous une voiture si oui 0 sinon 1 :
  Amortissement:
  Taille (: 0 = petit et 1 = grand):
Une fois toute les information remplis le code vous calcule votre impact carbonne. 

