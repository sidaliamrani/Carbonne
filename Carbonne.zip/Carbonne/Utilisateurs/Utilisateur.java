package Utilisateurs;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import ConsoCarbone.*;

public class Utilisateur {
    /* -------------------------- Donnees Membres -------------------------- */
    private Alimentation alimentation;
    private BienConso bienConso;
    private ArrayList<Transport> transports = new ArrayList<>();
    private ArrayList<Logement> logements = new ArrayList<>();
    private ServicesPublics servicesPublics = ServicesPublics.getInstance();
    private ArrayList<ConsoCarbone> consosCarbones = new ArrayList<>();
    /* -------------------------- Constructeurs  -------------------------- */
    public Utilisateur(){
        this.alimentation = new Alimentation();
        this.bienConso = new BienConso();
        Scanner scan = new Scanner(System.in);
        System.out.print("Nombre de moyens de transport: ");
        int trs = scan.nextInt();
        int i = 0, j = 0;
        System.out.print("Nombre de logement: ");        
        int lgs = scan.nextInt();
        while(j < trs ){
            this.transports.add(new Transport());
            j++;
        }    
        while(i < lgs){
            this.logements.add(new Logement());
            i++;
        }    
        this.consosCarbones.add(this.alimentation);
        this.consosCarbones.add(this.bienConso);
        int v = 0, w = 0;
        while(v < this.logements.size()){
            this.consosCarbones.add(this.logements.get(v));
            v++;
        }
        while(w < this.transports.size()){
            this.consosCarbones.add(this.transports.get(w));
            w++;
        }
        this.consosCarbones.add(this.servicesPublics);
    }
    public Utilisateur(String nomFichier) {
		try {
			BufferedReader br = Files.newBufferedReader(Paths.get(nomFichier));
            ArrayList<Transport> transports = new ArrayList<>();
            ArrayList<Logement> logements = new ArrayList<>();
            BienConso bienConso = new BienConso(Double.parseDouble(splitData(br.readLine())[1]));
            Alimentation alimentation = new Alimentation(Double.parseDouble(
                    splitData(br.readLine())[1]),
                    Double.parseDouble(splitData(br.readLine())[1])
            );
            int nbTransports = Integer.parseInt(splitData(br.readLine())[1]);
            for(int i = 0;i<nbTransports;i++){
                String[] tr = splitData(br.readLine());
                switch (Integer.parseInt(tr[1])) {
                    case 0:
                        transports.add(new Transport(true, Taille.P, Integer.parseInt(tr[2]), Integer.parseInt(tr[3])));
                    case 1:
                        transports.add(new Transport(true, Taille.G, Integer.parseInt(tr[2]), Integer.parseInt(tr[3])));

                }
            }
            int nbLogements = Integer.parseInt(splitData(br.readLine())[1]);
            for(int i = 0;i<nbLogements;i++){
                String[] tr = splitData(br.readLine());
                Logement l = new Logement(Integer.parseInt(tr[1]), CE.A);
                switch (Integer.parseInt(tr[2])) {
                    case 0:
                        l.setCE(CE.A);
                    case 1:
                        l.setCE(CE.B);
                    case 2:
                        l.setCE(CE.C);
                    case 3:
                        l.setCE(CE.D);
                    case 4:
                        l.setCE(CE.E);
                    case 5:
                        l.setCE(CE.F);
                    case 6:
                        l.setCE(CE.G);

                }
                logements.add(l);
            }
			br.close();
            this.alimentation = alimentation;
            this.bienConso = bienConso;
            this.transports = transports;
            this.logements = logements;
            this.consosCarbones.add(this.alimentation);
            this.consosCarbones.add(this.bienConso);
            this.consosCarbones.addAll(this.transports);
            this.consosCarbones.addAll(this.logements);
            this.consosCarbones.add(this.servicesPublics);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
    public Utilisateur(Alimentation alimentation, BienConso bienConso, ArrayList<Transport> transports, ArrayList<Logement> logements){
        this.alimentation = alimentation;
        this.bienConso = bienConso;
        this.transports = transports;
        this.logements = logements;
        this.consosCarbones.add(this.alimentation);
        this.consosCarbones.add(this.bienConso);
        this.consosCarbones.addAll(this.transports);
        this.consosCarbones.addAll(this.logements);
        this.consosCarbones.add(this.servicesPublics);
    }
    /* -------------------------- Getters  -------------------------- */
    public Alimentation getAlimentation(){
        return this.alimentation;
    }
    public BienConso getBienConso(){
        return this.bienConso;
    }
    public ArrayList<Transport> getTransports(){
        return this.transports;
    }
    public ArrayList<Logement> getLogements(){
        return this.logements;
    }
    public ServicesPublics getServicesPublics(){
        return this.servicesPublics;
    }
    /* -------------------------- Methodes -------------------------- */

    public void instruction(){
        int i = 0;
        while(i < this.consosCarbones.size()){
            this.consosCarbones.get(i).instruction();
            i++;
        }
     }
       
    public String[] splitData(String _ligne){
        return _ligne.split(";");
    }
    public double calculerEmpreinte(){
        double empreinte = 0.0;
        for (ConsoCarbone _consoCarbone: this.consosCarbones){
            empreinte+= _consoCarbone.getImpact();
        }
        return empreinte;
    }
    public void detaillerEmpreinte(){
        String empreinteDetail = "Detail de l'empreinte carbonne : \n";
        for (ConsoCarbone _consoCarbone: this.consosCarbones){
            empreinteDetail +="->    "+ _consoCarbone + "\n";
        }
        System.out.println(empreinteDetail);
    }
    public void ordonnerConsoCarbonne(){
        String str = "/---- Detail Empreinte Carbone Ordonnance -----/ \n";
        ArrayList<Double> tabImpact = new ArrayList<>();
        for (ConsoCarbone consoCarbone : this.consosCarbones){
            tabImpact.add(consoCarbone.getImpact());
        }
        Collections.sort(tabImpact);
        for(Double d : tabImpact){
            str += "-->    " + d + "\n";
        }
        System.out.println(str);
    }

    /**
     * Renvoi une description detaille d'un objet Utilisateur
     * @return String value
     */
    @Override public String toString(){
        String str = "";
        for (ConsoCarbone consoCarbone :  this.consosCarbones){
            str += consoCarbone;
        }
        str+="\nJ'ai un impact total de: "+this.calculerEmpreinte();
        return str;
    }
}
