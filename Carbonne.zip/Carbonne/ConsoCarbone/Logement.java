package ConsoCarbone;
import java.util.*;

/**
 * 
*/
public class Logement extends ConsoCarbone{
    /* -------------------------- Donnees Membres -------------------------- */
    /**
     *  la superficie du logement en m2
     */
    private int superficie;
    /**
     * la classe energetique du logement
     */
    private CE ce;
    /**
     *  l impact du logement en termes d emissions de GES en TCO2eq.
     */
    private double impact;
    /* -------------------------- Constructeurs -------------------------- */

    /**
     * Constructeur par default de la classe Logement
     */
    public Logement(){
        super();
        this.superficie = 0;
        this.ce = CE.G;
    }

    /**
     * Surcharge du Constructeur avec deux parametres en entree
     * @param _superficie : int value
     * @param _ce : Ce value
     */
    public Logement(int _superficie, CE _ce){
        super();
        this.superficie = _superficie;
        this.ce = _ce;
        this.makeImpact();
    }
    /* -------------------------- Getters -------------------------- */

    /**
     * getter pour la variable superficie
     * @return int value
     */
    public int getSuperficie(){
        return this.superficie;
    }
    /**
     * getter pour la variable CE
     * @return CE value
     */
    public CE getCE(){
        return this.ce;
    }
    /**
     * getter pour la variable id
     * @return int value
     */
    public int getId(){
        return super.getId();
    }

    /* -------------------------- Setters -------------------------- */

    /**
     * setter pour la variable superficie
     * @param _superficie : int value
     */
    public void setSuperficie(int _superficie){
        this.superficie = _superficie;
    }
    /**
     * setter pour la variable CE
     * @param _ce : CE value
     */
    public void setCE(CE _ce){
        this.ce = _ce;
    }
    /**
     * setter pour la variable impact
     */
    private void makeImpact(){
        this.impact = this.ce.getValue() * this.superficie;
    }

    /* -------------------------- Methodes -------------------------- */
    /**
     * Retourne sous la forme d'un string l'empreinte carbonne moyenne
     */
    public static void empreinteCarbonneMoyenne(){
        String msg = "Le logement en Kg eq C02 / an pour un français en fonction de son Empreinte carbonne moyenne \n";
        msg+="Energie et utilités : 1696\nConstruction et gros entretien : 675\nEquipement des logements : 335\nTotal : 2706";
        System.out.println(msg);
    }
    /**
     * fonction d'initialistation des donnees pour la classe Logement
     */
    @Override
    public void instruction(){
        System.out.println("/* -------------------------- instruction Classe Logement -------------------------- */\n");
        Scanner scan = new Scanner(System.in);
        System.out.print(String.format("La Superficie est de : %s", this.superficie));
        this.superficie = scan.nextInt();
        System.out.print("\n Choisir un chiffre entre 1 et 7 (ou A vaut 1, B vaut 2 ect...): ");
        int c = scan.nextInt();
        switch (c){
            case 1:
                this.ce=CE.A;
            case 2 :
                this.ce=CE.B;
            case 3 :
                this.ce=CE.C;
            case 4 :
                this.ce=CE.D;
            case 5 :
                this.ce=CE.E;
            case 6 :
                this.ce=CE.F;
            case 7 :
                this.ce=CE.G;

        }
        this.makeImpact();
    }
    /**
     * Renvoi une description detaillee d'un objet Logement
     * @return String value
     */
    @Override public String toString(){
        String str = super.toString() + String.format(
                "[\nLogement ::\nSuperficie : %s\nImpact : %s\n]\n"
                ,this.ce.getStringValue(),this.superficie,this.impact
        );
        return str;
    }
}