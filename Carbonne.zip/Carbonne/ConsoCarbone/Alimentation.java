package ConsoCarbone;
import java.util.*;

/**
 * @author sid ali et bilal
*/
public class Alimentation extends ConsoCarbone{

    /* -------------------------- Données Membres -------------------------- */
    /**
     *  le taux de repas (une valeur entre 0 et 1) a� base de boeuf (le type de
     * viande le plus emissif)
     */
    private double txBoeuf;
    /**
     * le taux de repas vegetariens
     */
    private double txVege;
    private final double a=8.0 ,b=1.6 ,c=0.9;
    /**
     *  l'impact de l'alimentation de l'utilisateur.rice en termes demissions de GES en TCO2eq
     */
    private double impact;

    /* -------------------------- Constructeurs -------------------------- */

    /**
     * Constructeur par default de la classe Alimentation
     */
    public Alimentation(){
        super();
        this.txBoeuf = 0.0;
        this.txVege = 0.0;
    }

    /**
     * Surcharge de Constructeur avec deux parametres en entree
     * @param _txBoeuf : double value (entre 0 et 1)
     * @param _txVege : double value (entre 0 et 1)
     */
    public Alimentation(double _txBoeuf, double _txVege){
        super();
        this.txBoeuf = _txBoeuf;
        this.txVege = _txVege;
        this.makeImpact();
    }
    /* -------------------------- Getters -------------------------- */

    /**
     * getter pour la variable taux boeuf
     * @return double value
     */
    public double getTxBoeuf(){
        return this.txBoeuf;
    }
    /**
     * getter pour la variable taux vege
     * @return double value
     */
    public double getTxVege(){
        return this.txVege;
    }
    /**
     * getter pour la variable id
     * @return int value
     */
    public int getId(){
        return super.getId();
    }

    /* -------------------------- Setters -------------------------- */

    /**
     * setter de la variable taux boeuf
     * @param _txBoeuf
     */

    public void setTxBoeuf(double _txBoeuf){
        this.txBoeuf = _txBoeuf;
    }

    /**
     * setter de la variable taux vege
     * @param _txVege
     */
    public void setTxVege(double _txVege){
        this.txVege = _txVege;
    }

    /**
     * setter pour la variable impact
     */
    private void makeImpact(){
        this.impact = this.a * this.txBoeuf + this.b * (1 - this.txVege - this.txBoeuf) + this.c * this.txVege;
    }

    /* -------------------------- Methodes -------------------------- */

    /**
     * fonction d'initialistation des donnees pour la classe Alimentation
     */
    @Override
    public void instruction(){
        System.out.println("/* ---------------- instruction class Alimentation ---------------------- *\\ \n");
        //On divise par 100 pour obtenir le taux en double et non en pourcentage
        Scanner scan = new Scanner(System.in);
        System.out.print("\n% de repas de vegetaux: ");
        this.txVege = scan.nextDouble()/100;
        System.out.print("\n% de repas de boeuf : ");
        this.txBoeuf = scan.nextDouble()/100;
        this.makeImpact();
    }


    /**
     * Retourne sous la forme d'un string l'empreinte carbonne moyenne
     */
    public static void empreinteCarbonneMoyenne(){
        System.out.println(
                "L'alimentation en Kg eq C02 / an d'un français en fonction de son Empreinte carbonne moyenne \n" +
                        "Viandes et poissons : 1144\nProduit laitiers et oeufs : 408\nAutes : 538\nBoissons : 263\nTotal : 2353"
        );
    }

    /**
     * cette fonction compare deux objets consocarbone entre eux
     * @param _consoCarbone
     */
    @Override 
    public void compare(ConsoCarbone _consoCarbone){
        super.compare(_consoCarbone);
    }
    /**
     * Renvoi une description detaillee d'un objet Alimentation
     * @return String value
     */
    @Override public String toString(){
        String str = super.toString() + String.format(
                "[\nAlimentation ::\nTaux de repas Boeuf : %s\nTaux de repas Végé : %s\nImpact : %s \n]\n"
                ,this.txBoeuf,this.txVege,this.impact
        );
        return str;
    }
}