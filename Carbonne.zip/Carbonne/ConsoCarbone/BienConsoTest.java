package ConsoCarbone;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class BienConsoTest {


	@Test
	void testToString() {
		BienConso a = new BienConso();
		assertEquals(a.toString(), super.toString() + String.format(
                "[\nBien Conso ::\nMontant : %s\nImpact : %s \n]\n"
                ,a.getMontant(),a.getImpact()
        ));
	}

	@Test
	void testBienConso() {
		BienConso a = new BienConso();
		assertEquals(a.getMontant(),0);
		
	}

	@Test
	void testGetMontant() {
		BienConso a = new BienConso();
		assertEquals(a.getMontant(), 0.0);
		
		
	}

	@Test
	void testSetMontant() {
		BienConso a = new BienConso();
		a.setMontant(9);
		assertEquals(a.getMontant(),9);
		
	}

}
