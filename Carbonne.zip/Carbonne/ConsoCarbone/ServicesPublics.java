package ConsoCarbone;

/**
 * Cette classe devant etre initialisee une et une seule fois suivra un design pattern de singletone
 */
public final class ServicesPublics extends ConsoCarbone{
    /* -------------------------- Donnees Membres -------------------------- */
    private static ServicesPublics instance = null;
    private double impact;
    /* -------------------------- Constructeur -------------------------- */

    /**
     * Constructeur par défault de la classe ServicesPublics
     */
    private ServicesPublics(){
        super();
        this.impact = 1.5;
    }
    /* -------------------------- Setter -------------------------- */

    /**
     * getter pour la variable instance
     * @return ServicesPublics value
     */
    public static ServicesPublics getInstance(){
        if (instance == null){
            instance = new ServicesPublics();
        }
        return instance;
    }
    /* -------------------------- Méthodes -------------------------- */
    /**
     * Renvoi une description detaillee d'un objet Services Publics
     * @return String value
     */
    @Override public String toString(){
        String str = super.toString()+String.format(
                "[\nService public ::\nImpact : %s\n]\n"
                ,this.impact
        );
        return str;
    }
}
