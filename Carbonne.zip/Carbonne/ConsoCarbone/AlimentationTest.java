package ConsoCarbone;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AlimentationTest {



	@Test
	void testGetId() {
		ConsoCarbone a = new ConsoCarbone();
		assertEquals(a.getId(),1);
	}

	@Test
	void testToString() {
		Alimentation a = new Alimentation();
		assertEquals(a.toString(), super.toString() + String.format(
                "[\nAlimentation ::\nTaux de repas Boeuf : %s\nTaux de repas Végé : %s\nImpact : %s \n]\n"
                ,a.getTxBoeuf(),a.getTxVege(),a.getImpact()));
	}


	@Test
	void testGetTxBoeuf() {
		Alimentation a = new Alimentation();
		assertEquals(a.getTxBoeuf(),0.0);
	}

	@Test
	void testGetTxVege() {
		Alimentation a = new Alimentation();
		assertEquals(a.getTxVege(),0.0);
	}

	@Test
	void testSetTxBoeuf() {
		Alimentation a = new Alimentation();
		a.setTxBoeuf(0.9);
		assertEquals(a.getTxBoeuf(),0.9);
	}

	@Test
	void testSetTxVege() {
		Alimentation a = new Alimentation();
		a.setTxVege(0.9);
		assertEquals(a.getTxVege(),0.9);
	}

	

}
