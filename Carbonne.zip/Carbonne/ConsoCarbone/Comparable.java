package ConsoCarbone;

public interface Comparable {
    void compare(ConsoCarbone _consoCarbone);
}
