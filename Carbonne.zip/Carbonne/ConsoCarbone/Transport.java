package ConsoCarbone;
import java.util.*;

public class Transport extends ConsoCarbone{
    /* -------------------------- Constructeur -------------------------- */
    /**
     * un boolean indiquant si l utilisateur.rice possede une voiture
     */
    private boolean possede;
    /**
     * la taille du vehicule
     */
    private Taille taille;
    /**
     * nombre de kilometres parcourus par an
     */
    private int killoAnnee;
    /**
     * duree de conservation du vehicule
     */
    private int amortissement;
    private double impact = 0.0;
    /* -------------------------- Constructeur -------------------------- */

    /**
     * Constructeur par default de la classe Transport
     */
    public Transport () {
        super();
        this.possede = false;
        this.taille = null;
        this.killoAnnee = 0;
        this.amortissement = 0;
    }

    /**
     * Surcharge de Constructeur avec 4 parametres en entree
     * @param _possede : boolean value
     * @param _taille : Taille value
     * @param _kilo : int value
     * @param _amt : int value
     */
    public Transport(boolean _possede, Taille _taille, int _kilo, int _amt){
        super();
        this.possede = _possede;
        this.taille = _taille;
        this.killoAnnee = _kilo;
        this.amortissement = _amt;
        this.makeImpact();
    }
    /* -------------------------- Constructeur -------------------------- */

    /**
     * getter pour la variable possede
     * @return boolean value
     */
    public boolean getPossede(){
        return this.possede;
    }
    /**
     * getter pour la variable taille
     * @return Taille value
     */
    public Taille getTaille(){
        return this.taille;
    }
    /**
     * getter pour la variable kilo
     * @return int value
     */
    public int getKilloAnnee(){
        return this.killoAnnee;
    }
    /**
     * getter pour la variable amortissement
     * @return int value
     */
    public int getAmortissement(){
        return this.amortissement;
    }
    /* -------------------------- Constructeur -------------------------- */

    /**
     * setter pour la variable possede
     * @param _possede : boolean value
     */
    public void setPossede(boolean _possede){
        this.possede = _possede;
    }
    /**
     * setter pour la variable Taille
     * @param _taille : Taille value
     */
    public void setTaille(Taille _taille){
        this.taille = _taille;
    }
    /**
     * setter pour la variable kilo
     * @param _kilo : int value
     */
    public void setKilloAnnee(int _kilo){
        this.killoAnnee = _kilo;
    }
    /**
     * setter pour la variable amt
     * @param _amt : int value
     */
    public void setAmortissement(int _amt){
        this.amortissement = _amt;
    }
    /**
     * setter pour la variable impact
     */
    private void makeImpact(){
        if (this.possede){
            this.impact = (this.killoAnnee * 1.93 * Math.pow(10,-4)) + (this.taille.getDoubleValue() / this.amortissement);
        }
    }
    /* -------------------------- Constructeur -------------------------- */
    /**
     * Retourne sous la forme d'un string l'empreinte carbonne moyenne
     */
    public static void empreinteCarbonneMoyenne(){
        String msg = "Le transport en Kg eq C02 / an d'un français en fonction de son Empreinte carbonne moyenne \n";
        msg+="Voiture : 1972\nAvion : 480\nFret et messagerie : 383\nTrain et bus : 85\nTotal : 2920";
        System.out.println(msg);
    }
    /* -------------------------- Méthodes -------------------------- */
    /**
     * fonction d'initialistation des donnees pour la classe Transport
     */
    @Override
    public void instruction(){
        System.out.println("/* -------------------------- instruction Classe Transport -------------------------- */\n");
        Scanner scan = new Scanner(System.in);
        // On veut instructionialiser this.possede
        System.out.print("Avez vous une voiture si oui 0 sinon 1 : \n");
        int reponse = scan.nextInt();
        System.out.println(reponse);
        if(reponse == 0)this.possede = true;
        else this.possede = false;
        System.out.print("\nCombien de killometrage par an: ");
        this.killoAnnee = scan.nextInt();
        System.out.print("\nAmortissement: ");
        this.amortissement = scan.nextInt();
        System.out.print("\n Taille (: 0 = petit et 1 = grand): ");
        int t = scan.nextInt();
        if(t == 0){
            this.taille = Taille.P;
        }else if (t == 1){
            this.taille = Taille.G;
        }else{
            this.taille = null;
        }
        this.makeImpact();
    }

    /**
     * Renvoi une description detaillee d'un objet Transport
     * @return String value
     */
    @Override public String toString(){
        if(possede){
            String str = super.toString()+String.format(
                    "[\ntransport ::\nTaille : %s\nkillometrage : %s\n]\n"
                    ,this.getKilloAnnee(),this.getTaille().getStringValue()
            );
            return str;
        }
        return "";
    }
}
