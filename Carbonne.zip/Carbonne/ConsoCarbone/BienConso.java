package ConsoCarbone;
import java.util.*;

 
public class BienConso extends ConsoCarbone{
    /* -------------------------- Donnees Membres -------------------------- */
    /**
     *  permet de connaitre le montant des
     * depenses annuelles de l utilisateur.rice
     */
    private double montant;
    private double impact;
    /* -------------------------- Constructeurs -------------------------- */

    /**
     * Constructeur par default de la classe BienConso
     */
    public BienConso(){
        super();
        this.montant = 0;
    }

    /**
     * Surcharge de Constructeur avec 1 parametre en entree
     * @param _montant
     */
    public BienConso(double _montant){
        super();
        this.montant = _montant;
        this.makeImpact();
    }
    /* -------------------------- Getter -------------------------- */

    /**
     * getter pour la variable montant
     * @return double value
     */
    public double getMontant(){
        return this.montant;
    }
    /* -------------------------- Setter -------------------------- */

    /**
     * setter pour la variable montant
     * @param _montant : double value
     */
    public void setMontant(double _montant){
        this.montant = _montant;
    }
    /**
     * setter pour la variable impact
     */
    private void makeImpact(){
        this.impact = this.montant / 1750;
    }
    /* -------------------------- Methodes -------------------------- */
    /**
     * Retourne sous la forme d'un string l'empreinte carbonne moyenne
     */
    public static void empreinteCarbonneMoyenne(){
        String str = "Le bien conso en Kg eq CO2 / an en fonction de son Empreinte carbonne moyenne \n";
        str+="Achat et usages / Internet et technologies : 1180\nAutres biens et services : 682\nHabillement : 763\nTotal : 2625";
        System.out.println(str);
    }
    /**
     * fonction d'initialistation des donnees pour la classe BienConso
     */
    @Override public void instruction(){
        System.out.println("/* -------------------------- instruction Classe BienConso -------------------------- */\n");
        Scanner scan = new Scanner(System.in);
        System.out.println(String.format("Le montant est de : "));
        this.montant = scan.nextDouble();
        this.makeImpact();
    }
    /**
     * Renvoi une description detaillee d'un objet BienConso
     * @return String value
     */
    @Override public String toString(){
        String str = super.toString() + String.format(
                "[\nBien Conso ::\nMontant : %s\nImpact : %s \n]\n"
                ,this.montant,this.impact
        );
        return str;
    }
    
}
