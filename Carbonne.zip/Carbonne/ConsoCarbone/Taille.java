package ConsoCarbone;

public enum Taille {
    P("petite voiture", 4.2),G("grande voiture", 19);

    private String stringValue;
    private double doubleValue;

    private Taille(String _taille, double _prod){
        this.stringValue = _taille;
        this.doubleValue = _prod;
    }
    /**
     * getter pour la variable string value
     * @return string value
     */
    public String getStringValue(){
        return this.stringValue;
    }
    /**
     * getter pour la variable double value
     * @return double value
     */
    public double getDoubleValue(){
        return this.doubleValue;
    }
}
