package ConsoCarbone;

/**
 * CE est une classe enum qui representant les
 * differentes classes energetiques possibles d un logement
 */
public enum CE{
    A("A",0.005),B("B",0.01),C("C",0.02),D("D",0.035),E("E",0.055),F("F",0.08),G("G",0.1);
    private String stringValue;
    private double doubleValue;

    private CE(String _stringValue, double _doubleValue){
        this.stringValue = _stringValue;
        this.doubleValue = _doubleValue;
    }

    /**
     * getter pour la variable double value
     * @return double value
     */
    public double getValue(){
        return this.doubleValue;
    }
    /**
     * getter pour la variable string value
     * @return String value
     */
    public String getStringValue(){
        return this.stringValue;
    }
}