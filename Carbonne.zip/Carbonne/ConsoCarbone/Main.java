package ConsoCarbone;

import Utilisateurs.Utilisateur;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        BienConso bc = new BienConso(480000);
        //Logement lo = new Logement(350, CE.A);
        //Alimentation a = new Alimentation(0.3, 0.7);
        //Transport tr = new Transport(true, Taille.G, 2000, 40);
        //ArrayList<Transport> t = new ArrayList<>();
        //ArrayList<Logement> l = new ArrayList<>();
        //t.add(tr);
        //l.add(lo);
        //Utilisateur perso1 = new Utilisateur("mon113455",a,bc,t,l);
        //perso1.ordonnerConsoCarbonne();
        //Utilisateur perso3 = new Utilisateur(System.getProperty("user.dir")+"/test.txt");
        //System.out.println(perso1);
        //System.out.println(perso3);
    	Utilisateur a = new Utilisateur();
    	a.instruction();
        System.out.println(a);
    }
    
}
