package ConsoCarbone;
/**
 * ConsoCarbone est une classe qui represente un poste de consommation carbone generique
 */
public class ConsoCarbone implements Comparable{

    /* -------------------------- Donnees Membres -------------------------- */
    private final int id;
    protected double impact;
    private static int lastId;
    /* -------------------------- Constructeur -------------------------- */

    /**
     * Constructeur par default de la classe ConsoCarbonne
     */
    public ConsoCarbone(){
        lastId++;
        this.id = lastId;
        this.impact = 0.0;
    }
    /* -------------------------- Getters -------------------------- */
    /**
     * getter pour la variable id
     * @return int id
     */
    public int getId(){
        return this.id;
    }
    /**
     * getter pour la variable impact
     * @return string impact
     */
    public double getImpact(){
        return this.impact;
    }
    /* -------------------------- Methodes -------------------------- */

    /**
     * cette methode compare deux objets consocarbonne en fonction de leur impact
     * @param _consoCarbone
     */
    public void compare(ConsoCarbone _consoCarbone){
        if(this.impact < _consoCarbone.getImpact()){
            System.out.println(String.format(" %s a un impact supErieur a� %s ",_consoCarbone,this));
        }else{
            System.out.println(String.format(" %s a un impact superieur a� %s ",this,_consoCarbone));
        }
    }
    public void instruction(){}
    /**
     * Renvoi une description detaillée d'un objet ConsoCarbone
     * @return String value
     */
    @Override public String toString(){
        return String.format("[\nConso Carbone ::\nId : %s\nImpact : %s \n]\n",this.getId(),this.impact);
    }
    /* -------------------------- Main -------------------------- */

    public static void main(String[] args) {
        //Create new object
        ConsoCarbone cb = new ConsoCarbone();
        System.out.println(cb.toString());
    }
}
